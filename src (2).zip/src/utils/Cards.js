import cardOut__img from '../images/cardOut__img.jpg';
import cardOut__img2 from '../images/cardOut__img2.jpg';
import cardOut__img3 from '../images/cardOut__img3.jpg';


export const Cards=[
    {
        title:"Colapso mental: cuando siento el peso del mundo sobre mí",
        subtitle:"Nutrición",
        description:"A veces nos sentimos como Atlas, aquel titán al que Zeus castigó y le obligó a llevar el peso de…",
        img:cardOut__img
    },
    {
        title:"Aprende a ser mamá",
        subtitle:"Educacion",
        description:"A veces nos sentimos como Atlas, aquel titán al que Zeus castigó y le obligó a llevar el peso de…",
        img:cardOut__img2
    },
    {
        title:"Aprende a ser mamá",
        subtitle:"Educacion ",
        description:"A veces nos sentimos como Atlas, aquel titán al que Zeus castigó y le obligó a llevar el peso de…",
        img:cardOut__img3
    }
]

