import {BiMenu} from "react-icons/bi";
import LiComp from "./LiComp";

const Aside = () =>{

    const openToMenu = () =>{
        const aside=document.querySelector("aside");
        console.log(aside);
        aside.classList.toggle("view");
    }

    return(
        <aside class="aside" id="aside__mobile">
            <button className="aside__button"><BiMenu className="aside__button--icon"/></button>
            <ul class="aside__ul">
                <h1>La Mente es Maravillosa</h1>
                <LiComp title="Embarazo" subtitles={["Quiero ser mama","Voy a ser mama","Parto"]}/>
                <LiComp title="Educacion" subtitles={["Aprende a ser mama","Educacion para bebes","Educacion para niños"]}/>
            </ul>
        </aside>
    )
}

export default Aside;