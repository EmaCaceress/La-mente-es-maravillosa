import {BiSearchAlt} from "react-icons/bi";

const NavBar = () =>{

    return(
        <nav className="navBar">
            <div style={{height:'20px',width:'20px'}}></div>
            <h1>La Mente es Maravillosa</h1>
            <BiSearchAlt style={{color:'black',fontSize:'5vw'}}/>
        </nav>
    );
}

export default NavBar;