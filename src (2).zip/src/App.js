import './App.css';
import Aside from './components/Aside';
import CardListContainer from './components/CardListContainer';
import Footer from './components/Footer';
import NavBar from './components/NavBar';
import index__img from './images/indeximg.jpg';

function App() {
  return (
    <div className="App">
      <header>
        <NavBar/>
        <Aside/>
      </header>
      <main className='main'>
        <section className='main__containerImg'>
          <img src={index__img} className='main__img'/>
        </section>
        <section className='main__containerTitle center'>
          <h1 className='main__title'>La Mente es Maravillosa</h1>
          <h2 className='main__description'>Cómo mejorar el clima, el capital humano, la comunicación o las negociaciones en una empresa?</h2>
        </section>
      </main>
      <article className='article'>
        <section className='article__opinions'></section>
        <CardListContainer/>
      </article>
      <Footer/>
    </div>
  );
}

export default App;
