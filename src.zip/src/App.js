import './App.css';
import Aside from './components/Aside';
import CardOutstanding from './components/CardOutstanding';
import Footer from './components/Footer';
import NavBar from './components/NavBar';

function App() {
  return (
    <div className="App">
      <header>
        <NavBar/>
        <Aside/>
      </header>
      <main className='main'>
        <section className='main__containerImg'>
          <img src="../images/indeximg.jpg" className='main__img'/>
        </section>
        <section className='main__containerTitle center'>
          <h1 className='main__title'>La Mente es Maravillosa</h1>
          <h2 className='main__description'>Cómo mejorar el clima, el capital humano, la comunicación o las negociaciones en una empresa?</h2>
        </section>
      </main>
      <article className='article'>
        <section className='article__opinions'></section>
        <section className='article__outstanding center'>
          <h1>Destacados</h1>
          <hr className="slash-3--blue"/>
          <CardOutstanding img="../images/cardOut__img" subtitle="Nutrición" title="Colapso mental: cuando siento el peso del mundo sobre mí" description="A veces nos sentimos como Atlas, aquel titán al que Zeus castigó y le obligó a llevar el peso de…"/>
        </section>
      </article>
      <Footer/>
    </div>
  );
}

export default App;
