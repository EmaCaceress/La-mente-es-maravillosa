import {CgCopyright} from "react-icons/cg";

const Footer = () =>{

    return(
        <footer className="footer">
            <div className="footer__container">
                <h1 className="title center">La Mente es Maravillosa</h1>
                <h2 className="subtitle center">mcontigo</h2> 
                <h3 className="center">La Mente es Maravillosa is a property of grupo MContigo
                <CgCopyright className="footer__container--icon"/>2021 - 2020. All rihts reserver.</h3>
                <h3 className="center">Los contenidos de esta publicacion se redactan solo con fines
                informativos. En ningun momento pueden server para facilitar
                diagnosticos o sustituir la labor de un profesional. Le
                recomendamos que contacte con su especialista de confianza.</h3>
            </div>
            <hr className="slash-3"/>
            <ul className="footer__ul center">
                <li>Politica de cookies</li>
                <li>Politica de privacidad</li>
                <li>Terminos y condiciones de uso</li>
                <li>Clausula informativa de uso</li>
            </ul>
        </footer>
    )
}

export default Footer;