
const CardOutstanding = ({img, subtitle, title, description}) =>{
    return(
        <div className="cardOut">
            <div className="cardOut__containerImg"><img src={img} className="cardOut_img"/></div>
            <div className="cardOut__container">
                <h2>{subtitle}</h2>
                <h1>{title}</h1>
                <h3>{description}</h3>
            </div>
            <button className='cardOut__button'>Ver Mas</button>
        </div>
    )
}

export default CardOutstanding;